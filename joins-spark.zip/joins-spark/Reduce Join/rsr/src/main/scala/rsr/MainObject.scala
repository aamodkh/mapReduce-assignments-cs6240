package rsr
import org.apache.spark.sql
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j.LogManager
import org.apache.log4j.Level
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.functions.broadcast
object MainObject {
  def main(args: Array[String]) {
    val logger: org.apache.log4j.Logger = LogManager.getRootLogger
    if (args.length != 2) {
      logger.error("Usage:\nscala.rsr.MainObject <input dir> <output dir>")
      System.exit(1)
    }
    val conf = new SparkConf().setAppName("RSR")
    val sc = new SparkContext(conf)
  	val rddInput = sc.textFile(args(0))
    //applying max filter to the input rdd and store each tuples with from column as key
  	val firstRdd = rddInput.map(_.split(",")).filter(row => row(0).toInt < 50000 && row(1).toInt < 50000).map(p => (p(0),p(1)))
  	//store each tuples with to column as key
    val secondRdd = firstRdd.map
  	{
      	  case (x,y) => (y,x)
  	}
  	//making main RDD for second join, "a" is just a dummy value.
  	val mainRdd  = firstRdd.map
  	{
  	  case (x,y) => ((x,y),"a")
  	}
  	//first join to obtain path2 in the form ((x,y),x)
  	val path2 = firstRdd.join(secondRdd).map
  	{
  	  case (x,y) => (y,x)
  	}
    //output contains the number of traingles times 3 tuples
  	val output = path2.join(mainRdd)
  	logger.info(output.toDebugString)
    //divide the count by 3 to get final count
  	println("The number of traingles is: "+ output.count()/3)
 	
  }
  
}
