package repr
import org.apache.spark.sql
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j.LogManager
import org.apache.log4j.Level
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.functions.broadcast
object MainObject {
  def main(args: Array[String]) {
    val logger: org.apache.log4j.Logger = LogManager.getRootLogger
    if (args.length != 2) {
      logger.error("Usage:\nscala.repr.MainObject <input dir> <output dir>")
      System.exit(1)
    }
    val conf = new SparkConf().setAppName("REPR")
    val sc = new SparkContext(conf)
    val counts = sc.longAccumulator
  	val rddInput = sc.textFile(args(0))
  	//use max filter of 50000 in the input RDD and obtain largeRdd for join
  	val largeRdd = rddInput.map(_.split(",")).filter(row => row(0).toInt < 50000 && row(1).toInt < 50000).map(p => (p(0),p(1)))
  	//here, both small and large rdd are same. smallRdd contains a set of "to" for each "from" ids
  	//The following line along with reduceByKey (_ ++ _) makes a set of "to" ids for each "from" ids.
    val smallRdd = largeRdd.map(p => (p._1, Set(p._2))).reduceByKey(_ ++ _)
    //smallRdd is broadcasted
    val cachedRdd = sc.broadcast(smallRdd.collectAsMap())
  	largeRdd.map
  	{
      case(x,y) => cachedRdd.value.getOrElse(y, Set[String]()).foreach 
    {
    	//foreach "to" ids of "y", we check if they have "x" as "to" or not. If so, increase counter
      f => if(cachedRdd.value.getOrElse(f,Set[String]()).contains(x))
      {
        counts.add(1)
      }          
  	}
  	}.collect() //collect for handling lazy transformation of spark
   logger.info(largeRdd.toDebugString)
  	
  	println("The number of traingles is: "+ counts.value/3)
 	
  }
  
}
