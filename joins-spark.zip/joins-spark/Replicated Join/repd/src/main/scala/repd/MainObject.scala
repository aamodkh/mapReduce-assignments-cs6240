package repd
import org.apache.spark.sql
import org.apache.log4j.LogManager
import org.apache.log4j.Level
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.functions.broadcast
object MainObject {
  def main(args: Array[String]) {
    val logger: org.apache.log4j.Logger = LogManager.getRootLogger
    if (args.length != 2) {
      logger.error("Usage:\nscala.repd.MainObject <input dir> <output dir>")
      System.exit(1)
    }
    val conf = new SparkConf().setAppName("REPD")
    val sc = new SparkContext(conf)
    val spark = SparkSession
  .builder()
  .appName("REPD")
  .getOrCreate()
  import spark.implicits._

  	val dfInput = spark.read.csv(args(0)).toDF("from","to")
  	
  	//maxfilter can be made dynamic by declaring a variable separately
  	val firstDf = dfInput.filter(dfInput("from") < 50000 && dfInput("to") < 50000) 

  	//to - from set is broadcasted and join is performed
  	//the id to be checked, grabbed in reverse order earlier are now compared with alternative.
  	// i.e to with from and from with to to complete the triangle.
    val smallDF = broadcast(firstDf)
  	val path2Df = firstDf.as("d1").join(smallDF.as("d2")).where($"d1.to" === $"d2.from").select($"d1.from",$"d2.to").toDF("from","to")
  	
  	//d1.from is selected just as a dummy to help the count later on.
  	//same key-value pairs are broadcasted for the second join also.
  	val triangle = path2Df.as("d1").join(smallDF.as("d2")).where($"d1.to" === $"d2.from" && $"d1.from" === $"d2.to").select($"d1.from")
  	
  	triangle.explain(extended = true)
  	println("The number of triangles is: "+ triangle.count()/3)
  }
  
}