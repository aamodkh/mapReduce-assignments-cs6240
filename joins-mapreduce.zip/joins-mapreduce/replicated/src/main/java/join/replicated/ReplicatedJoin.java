package join.replicated;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.commons.io.FilenameUtils;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Counter;
import java.net.URI;
import java.util.Set;
import java.util.HashSet;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class ReplicatedJoin extends Configured implements Tool
{
private static final Logger logger = LogManager.getLogger(ReplicatedJoin.class);

//using enum for global counter, at the end we have to divide TRNCOUNT by 3
public static enum TRIANGLES {
	 TRNCOUNT
	 };


public static class ReplicatedJoinMapper extends Mapper<Object, Text, Text, Text>
{

private static Map<String, Set<String>> followsTo;
//private final Text mapkey = new Text(); //if we need the actual paths, we can emit them using these keys
//private final Text mapvalue = new Text();
private int maxvalue;
@Override
protected void setup(Context context) throws IOException, InterruptedException 
{
	
	super.setup(context);
	//getting the threshold value from driver function
	maxvalue = Integer.parseInt(context.getConfiguration().get("max.value"));
	String path = context.getConfiguration().get("file.path");
    
    // one id may follow multiple other id.
    followsTo = new HashMap<>();

    URI[] edgeFiles = context.getCacheFiles();
    // All files from cache are retrieved in the array
    
    if (edgeFiles != null && edgeFiles.length > 0) 
    {
        for (URI edge : edgeFiles) {
        	Path filePath = new Path(edge.getPath());
        	File folder = new File(path);
		File[] listOfFiles = folder.listFiles();
		int count = 0;
		for(int i = 0; i < listOfFiles.length; i++)
		{
			count++;
			
			if(listOfFiles[i].getName().endsWith("csv"))
			{
			break;
			}
		}
		//change launchFile name to "input/edges.csv" when running in AWS.
		//BufferedReader bufferedReader = new BufferedReader(new FileReader("input/edges.csv"));
        BufferedReader bufferedReader = new BufferedReader(new FileReader(path+"/"+listOfFiles[count-1].getName()));
            String line;
            	while((line = bufferedReader.readLine())!=null)
            	{
            		String columns[] = line.split(",");
            		
            		if(columns.length == 2)  //to prevent program being affected by garbage data
            		{
            			int intkey = Integer.parseInt(columns[0]);
            			int intvalue = Integer.parseInt(columns[1]);
            			if(intkey < maxvalue && intvalue < maxvalue) //applying max filter
            			{
            				
            			
            			Set<String> toIds = null;
                     if (followsTo.get(columns[0]) == null) 
                     {
                         toIds = new HashSet<String>();
                         toIds.add(columns[1]);
                         followsTo.put(columns[0], toIds); //if no collision in hashmap, new value is added
                     } else {
                         toIds = followsTo.get(columns[0]);
                         toIds.add(columns[1]);
                         followsTo.put(columns[0],toIds); //if collision, the new value is added along with existing values
                     }
                     }
            		}
            	}
                
        		
     
        	
            
        }
    }

}

//mapper function
@Override
public void map(Object key, Text value, Context context) throws IOException, InterruptedException
{
	
	String follower[] = (value.toString()).split(",");
	int intkey = Integer.parseInt(follower[0]);
	int intvalue = Integer.parseInt(follower[1]);
	
	if(intkey < maxvalue && intvalue < maxvalue && followsTo.get(follower[1])!= null && !followsTo.get(follower[1]).isEmpty())
	{
	
			 //the control comes here if and only if there is a length 2 path from follower[1]
	           for(String all_ids : followsTo.get(follower[1]) )
	           {
	        	   
	        	   if(followsTo.get(all_ids)!= null && !followsTo.get(all_ids).isEmpty())
	        	   {
	        		   //collect all the endpoints of ids that are "to" of follower[to].
	        		   for (String level2 : followsTo.get(all_ids))
	        		   {
	        			  if(level2.equals(follower[0]))
	        			  {
	        				  //this position means the end point of follower[1] has an edge that ends to follower[0]
	        				  //i.e. this is what we are looking as a count
	        				  context.getCounter(TRIANGLES.TRNCOUNT).increment(1);
	        				  break;
	        				  //since we only care the number of triangles, the actual triangles are not stored.
	        			  }
	        				  
	        		   }
	        		 
	        	   }
	           }

	}
}


}
	
	

	@Override
	public int run(final String[] args) throws Exception {
		final Configuration conf = getConf();
		final Job job1 = Job.getInstance(conf, "Mapper Side Join");
		
		job1.addCacheFile(new Path(args[0]).toUri());
		job1.setJarByClass(ReplicatedJoin.class);
		final Configuration jobConf = job1.getConfiguration();
		jobConf.set("mapreduce.output.textoutputformat.separator", ",");
		String maxvalue = args[2];
		job1.getConfiguration().set("max.value", maxvalue);
		job1.getConfiguration().set("file.path", args[0]);
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		job1.setMapperClass(ReplicatedJoinMapper.class);
		job1.setNumReduceTasks(0);
		FileInputFormat.addInputPath(job1, new Path(args[0]));
		FileOutputFormat.setOutputPath(job1, new Path(args[1]));
		
		
		
		
		
		job1.waitForCompletion(true);
		
			if(job1.waitForCompletion(true))
			{
				return 0;
			}else
			{
				
				Counter counter = job1.getCounters().findCounter(TRIANGLES.TRNCOUNT); 
				System.out.println(counter.getDisplayName() + "\t" + counter.getValue());
				return 1;
				//the count is printed so that it appears on the log file.
				//Also, we have to divide this by 3 to get the triangle count.
			}
	}

	public static void main(final String[] args) {
		if (args.length != 3) {
			throw new Error("Three arguments required:\n<input-dir> <output-dir> <max-value>");
		}

		try {
			ToolRunner.run((Tool)new ReplicatedJoin(), args);
		} catch (final Exception e) {
		logger.error("", e);
		}
	}

}
