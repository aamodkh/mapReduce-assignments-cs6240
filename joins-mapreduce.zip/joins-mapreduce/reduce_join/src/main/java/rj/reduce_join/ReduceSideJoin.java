package rj.reduce_join;

import java.io.IOException;
import java.util.ArrayList;
//import java.util.Map;
//import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;



public class ReduceSideJoin extends Configured implements Tool
{
private static final Logger logger = LogManager.getLogger(ReduceSideJoin.class);
//first mapper
public static class SameMapper extends Mapper<Object, Text, Text, Text> 
{
		
		//private final static IntWritable one = new IntWritable(1);
		private final Text mapkeyf = new Text();
		private final Text mapvaluef = new Text();
		private final Text mapkeys = new Text();
		private final Text mapvalues = new Text();
		private int maxvalue;

		@Override
		public void setup(Context context) {
			
			maxvalue = Integer.parseInt(context.getConfiguration().get("max.value"));
		}
		
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			
			mapkeyf.set(follower[1]);
			// adds f to represent it is from first tuple and emits it
			mapvaluef.set("f" + follower[0]);
			mapkeys.set(follower[0]);
			// Flag this record for the reducer and then output
			mapvalues.set("s" + follower[1]);
			//mapvalue.set("s");
			int intkey = Integer.parseInt(follower[0]);
			int intvalue = Integer.parseInt(follower[1]);
			if(intkey < maxvalue && intvalue < maxvalue)
			{
				context.write(mapkeyf,mapvaluef);
				context.write(mapkeys,mapvalues);
			}
			

			
		}
}
//second mapper A
public static class MapContext extends Mapper<Object, Text, Text, Text> 
{
		
		//private final static IntWritable one = new IntWritable(1);
		private final Text mapkey = new Text();
		private final Text mapvalue = new Text();
		
		//a,b,c
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			mapkey.set(follower[1]+"_"+follower[0]);
			// adds c to represent it is from first tuple and emits it
			mapvalue.set("c");
			//mapvalue.set("s");
				context.write(mapkey,mapvalue);
				
			
		}
}
//second mapper B
public static class MapNew extends Mapper<Object, Text, Text, Text> 
{
		
		private final Text mapkey = new Text();
		private final Text mapvalue = new Text();
		private int maxvalue;
		@Override
		public void setup(Context context) {
			
			maxvalue = Integer.parseInt(context.getConfiguration().get("max.value"));
		}
		//a,b,c
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			int intkey = Integer.parseInt(follower[0]);
			int intvalue = Integer.parseInt(follower[1]);
			if(intkey < maxvalue && intvalue < maxvalue)
			{
			mapkey.set(follower[0]+"_"+follower[1]);
			// adds f to represent it is from first tuple and emits it
			mapvalue.set("n");
				context.write(mapkey,mapvalue);
			}	
			
			

			
		}
}


	
//Reducer second. This reduces all the counts into same key	
public static class ReducerClassInt extends Reducer<Text, Text, Text, Text> 
{
	private Text product = new Text();
	private int sumFirst;
	private int sumSecond;
	private Text keyname = new Text("k");
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		sumFirst = 0;
		sumSecond = 0;
		for (Text t : values) 
		{
			if (t.charAt(0) == 'c') 
			{
				sumFirst+=1;
				//it counts how many keys are looking for the same edge.
				
			} else if (t.charAt(0) == 'n') 
			{
				sumSecond+=1;				
				//it becomes 1 if and only if the edge to be inspected is in the input file
			}
		}
		product = new Text(Integer.toString(sumFirst));
		//product = sumFirst;
		if (sumFirst * sumSecond > 0)
		{
			context.write(keyname, product);
		}
		//context.write(key, product);

		
	}

	
}


//ReducerFirst 
public static class ReducerClass extends Reducer<Text, Text, Text, Text> 
{

	private ArrayList<Text> listFirst = new ArrayList<Text>();
	private ArrayList<Text> listSecond = new ArrayList<Text>();
	

	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		// Clear our lists
		listFirst.clear();
		listSecond.clear();
		
		
		// iterate through all our values, binning each record based on what
		// it was tagged with
		for (Text t : values) 
		{
			if (t.charAt(0) == 'f') 
			{
				Text f = new Text(t.toString().substring(1));
				listFirst.add(f);
				
			} else if (t.charAt(0) == 's') 
			{
				Text s = new Text(t.toString().substring(1));
				listSecond.add(s);
				
			}
		}
		
		//context.write(hi, hello);

		// If both lists are not empty, join A with B
			if (!listFirst.isEmpty() && !listSecond.isEmpty()) {
				
				for (Text A : listFirst) {
					for (Text B : listSecond) {
						context.write(A,B);
					}
				}
			}
	}

	
}
//Mapper third
public static class MapFinal extends Mapper<Object, Text, Text, IntWritable> 
{
		
		private IntWritable mapvalue = new IntWritable();
		private final Text mapkey = new Text();
		
		
		//a,b,c
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			mapkey.set(follower[0]);
			mapvalue = new IntWritable(Integer.parseInt(follower[1]));
			context.write(mapkey,mapvalue);
			}		
		
}
//Reducer third, started only for one time
public static class ReducerFinal extends Reducer<Text, IntWritable, Text,Text> 
{

	private final Text result = new Text();

	@Override
	public void reduce(final Text key, final Iterable<IntWritable> values, final Context context) throws IOException, InterruptedException {
		long sum = 0;
		for (final IntWritable val : values) {
			sum += val.get();
		}
		result.set(Long.toString(sum/3));
		context.write(key, result);
	}	
}

	
	

	@Override
	public int run(final String[] args) throws Exception {
		final Configuration conf = getConf();
		final Job job1 = Job.getInstance(conf, "Reducer Side Join");
		
		job1.setJarByClass(ReduceSideJoin.class);
		final Configuration jobConf = job1.getConfiguration();
		jobConf.set("mapreduce.output.textoutputformat.separator", ",");
		String maxvalue = args[2];
		job1.getConfiguration().set("max.value", maxvalue);
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		MultipleInputs.addInputPath(job1, new Path(args[0]),TextInputFormat.class, SameMapper.class);
		job1.setReducerClass(ReducerClass.class);
		FileOutputFormat.setOutputPath(job1, new Path(args[1]+"/step1"));
		
		job1.waitForCompletion(true);
		
			final Job job2 = Job.getInstance(conf, "Count Triangles");
			job2.setJarByClass(ReduceSideJoin.class);
			
			final Configuration jobConf2 = job2.getConfiguration();
			jobConf2.set("mapreduce.output.textoutputformat.separator", ",");
			job2.getConfiguration().set("max.value", maxvalue);
			MultipleInputs.addInputPath(job2, new Path(args[0]),TextInputFormat.class, MapNew.class);
			MultipleInputs.addInputPath(job2, new Path(args[1]+"/step1"),TextInputFormat.class, MapContext.class); 
			job2.setReducerClass(ReducerClassInt.class);
			job2.setOutputKeyClass(Text.class);
			job2.setOutputValueClass(Text.class);
			// delete file, true for recursive
			FileOutputFormat.setOutputPath(job2, new Path(args[1]+"/step2"));
			job2.waitForCompletion(true);
			
			final Job job3 = Job.getInstance(conf, "final count");
			job3.setJarByClass(ReduceSideJoin.class);
			
			final Configuration jobConf3 = job3.getConfiguration();
			jobConf3.set("mapreduce.output.textoutputformat.separator", ",");
			job3.setMapperClass(MapFinal.class);
			job3.setNumReduceTasks(1);
			job3.setReducerClass(ReducerFinal.class);
			job3.setOutputKeyClass(Text.class);
			job3.setOutputValueClass(IntWritable.class);
			// delete file, true for recursive
			FileInputFormat.addInputPath(job3, new Path(args[1]+"/step2"));
			FileOutputFormat.setOutputPath(job3, new Path(args[1]+"/step3"));
			
			if(job3.waitForCompletion(true))
			{
				return 0;
			}else
			{
				return 1;
			}
	}

	public static void main(final String[] args) {
		if (args.length != 3) {
			throw new Error("Three arguments required:\n<input-dir> <output-dir> <max-value>");
		}

		try {
			ToolRunner.run((Tool)new ReduceSideJoin(), args);
		} catch (final Exception e) {
		logger.error("", e);
		}
	}

}
