package max.max_filter;



import java.io.IOException;
import java.util.ArrayList;
//import java.util.Map;
//import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.hadoop.fs.FileSystem;

public class MaxFilter extends Configured implements Tool
{
private static final Logger logger = LogManager.getLogger(MaxFilter.class);
//first mapper 
public static class SameMapper extends Mapper<Object, Text, Text, Text> 
{
		
		//private final static IntWritable one = new IntWritable(1);
		private final Text mapkeyf = new Text();
		private final Text mapvaluef = new Text();
		private final Text mapkeys = new Text();
		private final Text mapvalues = new Text();
		
		
		
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			
			mapkeyf.set(follower[1]);
			mapvaluef.set("f"+follower[0]);
			mapkeys.set(follower[0]);
			// Flag this record for the reducer and then output
			mapvalues.set("s"+follower[1]);
			context.write(mapkeyf,mapvaluef);
			context.write(mapkeys,mapvalues);
			
			

			
		}
}


//second mapper
public static class MapNew extends Mapper<Object, Text, Text, IntWritable> 
{
		
		private IntWritable mapvalue = new IntWritable();
		private final Text mapkey = new Text();
		
		
		//a,b,c
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException {
			String follower[] = (value.toString()).split(",");
			mapkey.set(follower[0]);
			mapvalue = new IntWritable(Integer.parseInt(follower[1]));
			context.write(mapkey,mapvalue);
			}		
		
}


	
//second reducer class, it counts each time a key forms a path	
public static class ReducerClassInt extends Reducer<Text, Text, Text, Text> 
{
	private Text product = new Text();
	private int sumFirst;
	private int sumSecond;
	private Text keyname = new Text("key");
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		sumFirst = 0;
		sumSecond = 0;
		for (Text t : values) 
		{
			if (t.charAt(0) == 's') 
			{
				sumFirst+=1;
				
				
			} else if (t.charAt(0) == 'f') 
			{
				sumSecond+=1;				
			}
		}
		product = new Text(Integer.toString(sumFirst* sumSecond));
		//product = sumFirst;
		if ((sumFirst * sumSecond) > 0)
		{
			context.write(keyname, product);
		}
		//context.write(key, product);

		
	}

	
}


//last reducer, only one is started.
public static class ReducerClass extends Reducer<Text, IntWritable, Text,Text> 
{

	private final Text result = new Text();

	@Override
	public void reduce(final Text key, final Iterable<IntWritable> values, final Context context) throws IOException, InterruptedException {
		long sum = 0;
		for (final IntWritable val : values) {
			sum += val.get();
		}
		result.set(Long.toString(sum));
		context.write(key, result);
	}

	
}




	
	

	@Override
	public int run(final String[] args) throws Exception {
		final Configuration conf = getConf();
		final Job job1 = Job.getInstance(conf, "Reducer Side Join");
		
		job1.setJarByClass(MaxFilter.class);
		final Configuration jobConf = job1.getConfiguration();
		jobConf.set("mapreduce.output.textoutputformat.separator", ",");
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		MultipleInputs.addInputPath(job1, new Path(args[0]),TextInputFormat.class, SameMapper.class);
		job1.setReducerClass(ReducerClassInt.class);
//		job.setReducerClass(ReducerClassInt.class);
		//job.setMapperClass(MapNew.class);
		//MultipleInputs.addInputPath(job, new Path(args[0]),TextInputFormat.class, MapContext.class);
		FileOutputFormat.setOutputPath(job1, new Path(args[1]+"/step1"));
		
		job1.waitForCompletion(true);
		
			final Job job2 = Job.getInstance(conf, "Count Paths");
			job2.setJarByClass(MaxFilter.class);
			
			final Configuration jobConf2 = job2.getConfiguration();
			jobConf2.set("mapreduce.output.textoutputformat.separator", ",");
			job2.setMapperClass(MapNew.class);
			job2.setNumReduceTasks(1);
			job2.setReducerClass(ReducerClass.class);
			job2.setOutputKeyClass(Text.class);
			job2.setOutputValueClass(IntWritable.class);
			// delete file, true for recursive
			FileInputFormat.addInputPath(job2, new Path(args[1]+"/step1"));
			FileOutputFormat.setOutputPath(job2, new Path(args[1]+"/step2"));
			if(job2.waitForCompletion(true))
			{
				return 0;
			}else
			{
				return 1;
			}
	}

	public static void main(final String[] args) {
		if (args.length != 2) {
			throw new Error("Two arguments required:\n<input-dir> <output-dir> ");
		}

		try {
			ToolRunner.run((Tool)new MaxFilter(), args);
		} catch (final Exception e) {
		logger.error("", e);
		}
	}

}
