package mr.pagerank;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.NLineInputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class PageRank extends Configured implements Tool
{
private static final Logger logger = LogManager.getLogger(PageRank.class);

enum DCOUNTER {
	
	DANGLING, TOTAL 
	//dangling for dangling mass and total is for total probability sum
	//the dangling mass is multiplied by 1000000
	//so  that it becomes easier to observe the count. Else, we get 0 value everytime
}
//mapper class
public static class MapNew extends Mapper<Object, Text, Text, Text> 
{
	 double danglingMass;
	 int vertexCount;
	  @Override
		public void setup(Context context) throws IOException, InterruptedException
	  {

			danglingMass = (Double.parseDouble(context.getConfiguration().get("danglingMass")))/1000000;
			vertexCount = Integer.parseInt(context.getConfiguration().get("vertexCount"));
	  }
		
	
		private final Text mapkey = new Text();
		private final Text mapvalue = new Text();
		
	
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException 
		{
			String follower[] = (value.toString()).split("[*?]|(,)");
			String adjlist[] = follower[1].replace("[","").replace("]","").split(",");
			double rank = Double.parseDouble(follower[2]);
			
			//adding dangling mass to the rank of node id.
			//if(Integer.parseInt(follower[0])!=0)
			rank= rank+ 0.85*(danglingMass/(double)vertexCount);
			
			//emit graph structure for other iterations
			mapkey.set(follower[0]);
			mapvalue.set(follower[1]);
			context.write(mapkey,mapvalue);
			
			//mapkey.set(follower[0]);
			//mapvalue.set("0.0");
			//compute contribution for each of the adjacency list items
			
				
				for(String item:adjlist ) 
				{
					if(!item.isEmpty() && !follower[0].equalsIgnoreCase("0"))
					{
						double prvalue = (double) (rank/adjlist.length) ;
						mapkey.set(item);
						mapvalue.set(prvalue+"");
						context.write(mapkey,mapvalue);
					}
					
				}
				
			
		}		
		
}

//mapper for compensating dangling weight of after iteration
public static class MapLast extends Mapper<Object, Text, Text, Text> 
{
	 double danglingMass;
	  int vertexCount;
	  @Override
		public void setup(Context context) throws IOException, InterruptedException
	  {

			danglingMass = (Double.parseDouble(context.getConfiguration().get("danglingMass")))/1000000;
			vertexCount = Integer.parseInt(context.getConfiguration().get("vertexCount"));
	  }
		
		private final Text mapkey = new Text();
		private final Text mapvalue = new Text();
		
		
		@Override
		public void map(final Object key, final Text value, final Context context) throws IOException, InterruptedException 
		{
			String follower[] = (value.toString()).split("[*?]|(,)");
			double rank = Double.parseDouble(follower[2]);
			
			//neutralizing the mass accumulated in dummy node
			if((follower[0]).equals("0"))
			{
				rank = 0;
				
			}else
			{
				//adding dangling mass to the rank of node id.
				rank += 0.85*(danglingMass/vertexCount);
				context.getCounter(DCOUNTER.TOTAL).increment((long)(rank*1000000));
			}
				//emit graph structure for other iterations
				mapkey.set(follower[0]);
				mapvalue.set(follower[1]+","+rank);
				context.write(mapkey,mapvalue);
			
			
		}		
		
}

//partitioner
//Partitioner class for arranging the final outputs a little bit
//secondary sorting is not done, only the data are grouped so that first 10k ids are in the first file and so on.

public static class CustomPartition extends
Partitioner < Text, Text >
{
   @Override
   public int getPartition(Text key, Text value, int numReduceTasks)
   {
	int id = Integer.parseInt(key.toString());
    if(numReduceTasks == 0)
      {
         return 0;
      }
      if(id<=10000)
      {
         return 0;
      }
      else if(id>10001 && id<=100000)
      {
         return 1 % numReduceTasks;
      }
      else if(id>100001 && id<=200000)
      {
         return 2 % numReduceTasks;
      }
      else if(id>200001 && id<=400000)
      {
         return 3 % numReduceTasks;
      }
      else if(id>400001 && id<=600000)
      {
         return 4 % numReduceTasks;
      }
      else if(id>600001 && id<=800000)
      {
         return 5 % numReduceTasks;
      }
      else
      {
         return 6 % numReduceTasks;
      }
   }
}

//Reducer class
	  public static class ReducerClass extends Reducer<Text, Text, Text,Text> 
	  {
		  int vertexCount;
		  double danglingMass;
		  @Override
			public void setup(Context context) throws IOException, InterruptedException
		  {
			  	danglingMass = (Double.parseDouble(context.getConfiguration().get("danglingMass")))/1000000;
				vertexCount = Integer.parseInt(context.getConfiguration().get("vertexCount"));
		  }
		  
		  
	  // private final Text result = new Text();
		
		private Text graph = new Text();
	  @Override public void reduce(final Text key, final Iterable<Text> values,
	  final Context context) throws IOException, InterruptedException 
	  {
		  double score;
		  double temp = 0.0;
		  String graphString = "";
	  for (final Text val : values) 
	  { 
		if((val.toString()).contains("["))
		{
			graphString = val.toString();
		}
		else
		{
			temp+= Double.parseDouble(val.toString());
		}
	  }
	  score = ((0.15/vertexCount) + 0.85 *temp); 
	  if(Integer.parseInt(key.toString()) == 0)
	  {
		  context.getCounter(DCOUNTER.DANGLING).setValue((long)(temp * 1000000));
		  score = temp;
	  }
	  graph.set(graphString+","+score);
	  context.write(key,graph);
	  }
	  
	 }
	 

	@Override
	public int run(final String[] args) throws Exception 
	{
		//first and last iteration are done outside loop. An extra job is run at the end to
		//distribute the dangling mass of the last iteration
		final int k = 1000;
		int i =1;
		final int iteration = 9; //as first iteration is done explicitly
		double danglingMass = 0.0;
	
		Job job1 = createNewJob(i,danglingMass,k, args[0], args[1]);
		job1.waitForCompletion(true);
		
		danglingMass = (double)job1.getCounters().findCounter(DCOUNTER.DANGLING).getValue();
		do
		{
			
			Job job = createNewJob(i+1,danglingMass,k, args[1]+"/step"+i, args[1]);
			job.waitForCompletion(true);
			i++;
			danglingMass = (double)job.getCounters().findCounter(DCOUNTER.DANGLING).getValue();
			
		}while(i<iteration);
		
		//last iteration is done outside the loop
		Job job10 = createNewJob(i+1,danglingMass,k, args[1]+"/step"+i, args[1]);
		job10.waitForCompletion(true);
		
		
		//code for generating file with final pagerank values
		//map only job
		
		danglingMass = job10.getCounters().findCounter(DCOUNTER.DANGLING).getValue();
		Configuration confx = getConf();
		Job job11 = Job.getInstance(confx, "Page Rank Final");
		job11.setJarByClass(PageRank.class);
		Configuration jobConfx = job11.getConfiguration();
		jobConfx.set("danglingMass", (danglingMass+""));
		jobConfx.set("vertexCount", ((k*k)+""));
		jobConfx.set("mapreduce.output.textoutputformat.separator", ",");
		job11.setOutputKeyClass(Text.class);
		job11.setOutputValueClass(Text.class);
		
		i++;
		MultipleInputs.addInputPath(job11, new Path(args[1]+"/step"+i),TextInputFormat.class, MapLast.class);
		job11.setPartitionerClass(CustomPartition.class);
		job11.setNumReduceTasks(7);
		job11.setReducerClass(Reducer.class);
		i++;
		FileOutputFormat.setOutputPath(job11, new Path(args[1]+"/step"+i));
		if(job11.waitForCompletion(true))
		{
			return 0;
		}else
		{
			Counter counter2 = job11.getCounters().findCounter(DCOUNTER.TOTAL); 
			System.out.println("Total probability is" + "\t" + (double)(counter2.getValue())/1000000);
			return 1;
		}
			
	}

	public static void main(final String[] args) {
		if (args.length != 2) {
			throw new Error("Exactly two arguments required:\n<input-dir> <output-dir> ");
		}

		try {
			ToolRunner.run((Tool)new PageRank(), args);
		} catch (final Exception e) {
		logger.error("", e);
		}
	}
	
	//this function is called in each iteration to create the job.
	private Job createNewJob(int i,double danglingMass,int k, String input, String output)  throws IOException
	{
		Configuration conf = getConf();
		Job job1 = Job.getInstance(conf, "Page Rank"+i);
		job1.setJarByClass(PageRank.class);
		Configuration jobConf = job1.getConfiguration();
		jobConf.set("danglingMass", (danglingMass+""));
		jobConf.set("vertexCount", ((k*k)+""));
		jobConf.set("mapreduce.output.textoutputformat.separator", ",");
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		job1.setInputFormatClass(NLineInputFormat.class);
		NLineInputFormat.addInputPath(job1, new Path(input));
		//k*k = 1000000 is the total number of rows. So, dividing it with 25 is 40000.
		//so, each map task will receive 40000 rows such that the number of map task is more than 20.
		//Here, 25 is just an arbitrary number greater than 20.
		job1.getConfiguration().setInt("mapreduce.input.lineinputformat.linespermap", (k*k)/25);
		job1.setMapperClass(MapNew.class);
		job1.setReducerClass(ReducerClass.class);
		FileOutputFormat.setOutputPath(job1, new Path(output+"/step"+i));
		return job1;
	}

}