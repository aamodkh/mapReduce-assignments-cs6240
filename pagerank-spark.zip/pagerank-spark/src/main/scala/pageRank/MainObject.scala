package pageRank
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.log4j.LogManager
import org.apache.log4j.Level
object MainObject {
  def main(args: Array[String]) {
    val logger: org.apache.log4j.Logger = LogManager.getRootLogger
    if (args.length != 2) {
      logger.error("Usage:\nscala.pageRank.MainObject <input dir> <output dir>")
      System.exit(1)
    }
    val conf = new SparkConf().setAppName("pageRank")
    val sc = new SparkContext(conf)
  
  //assign the value of k here
  val k = 100
  
  //create graphs in the format (nodeid1,nodeid2)
  
  val graphs = sc.range(1,((k*k)+1).toInt,1).map
  {
      case (x) => (if (x%k !=0) (x.toInt,(x+1).toInt) else (x.toInt,0.toInt))
        
  }
  //to add (0,0.0) at the end, the graph is taken, values are only changed to 1/|v|
    //and then (0,0.0) is also added by performing union with another rdd (0,0.0)  
  var ranks = graphs.mapValues
  {
    case (x) => 1.0/(k.toDouble*k.toDouble)
  }.union(sc.parallelize(List(0)).map(x => (x,(0))))
  
  //the adjacency list is created from the graph RDD as below
  
  val links = graphs.map(x => (x._1,List(x._2))).reduceByKey(_ ++ _)
  
  var i = 1
  //iteration starts here
  for (i <- 1 to 10)
  {
    //calculation of contributions
    val contributions = links.join(ranks).flatMap
   {
      case(nodeid, (adjlist, pval)) => 
          adjlist.flatMap(dest => (List((dest,pval/(adjlist.size).toDouble),(nodeid,0.0))))
        
    }.reduceByKey(_+_)
    
    //to find dangling mass, lookup is used
    
    val dangling = contributions.lookup(0).head
  ranks = contributions.map
  {
    case(key,v) => 
      (if (key != 0)
        {

          (key,(0.15)/(k.toDouble*k.toDouble) + 0.85 *(v+ (dangling/(k.toDouble*k.toDouble))))
        }else
        {
          (key,0.0)
        })
  }.sortByKey(true).cache() //cache is used in ranks

 }
  //iteration ends here
  
  //total probability
  val total = ranks.map(_._2).sum()
  logger.info(ranks.toDebugString)
  //repartition is used so that spark does not generate a lot of output files
  ranks.saveAsTextFile(args(1))
    println("The total probability is: "+ total)
  }
}
